﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'ug', {
	label: 'ئۇسلۇب',
	panelTitle: 'ئۇسلۇب',
	panelTitle1: 'بۆلەك دەرىجىسىدىكى ئېلېمېنت ئۇسلۇبى',
	panelTitle2: 'ئىچكى باغلانما ئېلېمېنت ئۇسلۇبى',
	panelTitle3: 'نەڭ (Object) ئېلېمېنت ئۇسلۇبى'
} );
