﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'en-au', {
	label: 'Styles',
	panelTitle: 'Formatting Styles',
	panelTitle1: 'Block Styles',
	panelTitle2: 'Inline Styles',
	panelTitle3: 'Object Styles'
} );
