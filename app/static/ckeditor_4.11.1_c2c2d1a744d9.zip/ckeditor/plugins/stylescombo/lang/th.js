﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'th', {
	label: 'ลักษณะ',
	panelTitle: 'Formatting Styles', // MISSING
	panelTitle1: 'Block Styles', // MISSING
	panelTitle2: 'Inline Styles', // MISSING
	panelTitle3: 'Object Styles' // MISSING
} );
