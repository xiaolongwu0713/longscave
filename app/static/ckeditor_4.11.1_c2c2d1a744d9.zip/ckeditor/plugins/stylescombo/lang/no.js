﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'no', {
	label: 'Stil',
	panelTitle: 'Stilformater',
	panelTitle1: 'Blokkstiler',
	panelTitle2: 'Inlinestiler',
	panelTitle3: 'Objektstiler'
} );
