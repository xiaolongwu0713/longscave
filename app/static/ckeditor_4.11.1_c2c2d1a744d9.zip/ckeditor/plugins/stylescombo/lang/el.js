﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'el', {
	label: 'Μορφές',
	panelTitle: 'Στυλ Μορφοποίησης',
	panelTitle1: 'Στυλ Τμημάτων',
	panelTitle2: 'Στυλ Εν Σειρά',
	panelTitle3: 'Στυλ Αντικειμένων'
} );
