﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'en-ca', {
	options: 'Special Character Options', // MISSING
	title: 'Select Special Character',
	toolbar: 'Insert Special Character'
} );
