﻿/*
Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'ar', {
	confirmCleanup: 'يبدو أن النص المراد لصقه منسوخ من برنامج وورد. هل تود تنظيفه قبل الشروع في عملية اللصق؟',
	error: 'لم يتم مسح المعلومات الملصقة لخلل داخلي',
	title: 'لصق من وورد',
	toolbar: 'لصق من وورد'
} );
